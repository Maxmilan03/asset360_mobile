/// Backend settings, passed at run time only (never hard-coded):
///
/// ```sh
/// flutter run --dart-define=USE_API=true \
///   --dart-define=API_BASE_URL=http://<backend-ip>:5296 \
///   --dart-define=AUTH_BASE_URL=http://<backend-ip>:5018
/// ```
///
/// See README → "Connecting to the backend".
library;

import 'package:flutter/foundation.dart';

/// True: sign-in and repositories use the backend; false (default): the mock data in lib/data/mock/
/// and the demo login (rex.kumar / Asset@360 / 123456). Code reads [apiMode], which tests can override.
const bool kUseApi = bool.fromEnvironment('USE_API');

/// API Gateway root, e.g. http://192.168.1.20:5296 (no trailing /api).
const String kApiBaseUrl = String.fromEnvironment('API_BASE_URL');

/// UserAccount (login) service root, e.g. http://192.168.1.20:5018.
const String kAuthBaseUrl = String.fromEnvironment('AUTH_BASE_URL');

/// Optional debug override: a Bearer token for the gateway, used only while nobody is signed in.
const String kDevToken = String.fromEnvironment('DEV_TOKEN');

/// Tests set this to run the API sign-in flow without --dart-define.
@visibleForTesting
bool? debugApiMode;

/// True when the app talks to the backend ([kUseApi], or a test override).
bool get apiMode => debugApiMode ?? kUseApi;

String? _urlProblem(String name, String value, String port) => switch (value) {
  '' => '$name is not set. Run with --dart-define=$name=http://<backend-ip>:$port',
  _ when Uri.tryParse(value)?.hasScheme != true => '$name "$value" must start with http:// or https://',
  _ => null,
};

/// What is missing to call the gateway, or null when API_BASE_URL is usable.
String? get apiConfigProblem => _urlProblem('API_BASE_URL', kApiBaseUrl, '5296');

/// What is missing to call the login service, or null when AUTH_BASE_URL is usable.
String? get authConfigProblem => _urlProblem('AUTH_BASE_URL', kAuthBaseUrl, '5018');
