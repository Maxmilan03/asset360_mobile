import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:asset360_mobile/data/api/api_config.dart';
import 'package:asset360_mobile/data/api/api_exception.dart';

/// The one Dio instance for the API Gateway. Only repositories and API classes use it; screens
/// never call HTTP directly. Tests override this provider with a fake adapter.
final dioProvider = Provider<Dio>((ref) {
  final dio = Dio(
    BaseOptions(
      baseUrl: kApiBaseUrl,
      connectTimeout: const Duration(seconds: 10),
      sendTimeout: const Duration(seconds: 30),
      receiveTimeout: const Duration(seconds: 30),
      headers: {'Accept': 'application/json'},
      responseType: ResponseType.json,
    ),
  );
  dio.interceptors.add(AuthInterceptor(tokenProvider: () => kDevToken));
  if (kDebugMode) dio.interceptors.add(DebugLogInterceptor());
  ref.onDispose(dio.close);
  return dio;
});

/// Thin wrapper the API classes use: every error comes out as an [ApiException].
final apiClientProvider = Provider<ApiClient>((ref) => ApiClient(ref.watch(dioProvider)));

class ApiClient {
  const ApiClient(this.dio, {this.checkConfig = true});

  final Dio dio;

  /// False in tests, which talk to a fake adapter without dart-defines.
  final bool checkConfig;

  Future<Response<T>> get<T>(String path, {Map<String, dynamic>? query}) =>
      _guard(() => dio.get<T>(path, queryParameters: query));

  Future<Response<T>> post<T>(String path, {Object? data, Map<String, dynamic>? query}) =>
      _guard(() => dio.post<T>(path, data: data, queryParameters: query));

  Future<Response<T>> put<T>(String path, {Object? data, Map<String, dynamic>? query}) =>
      _guard(() => dio.put<T>(path, data: data, queryParameters: query));

  Future<Response<T>> delete<T>(String path, {Object? data, Map<String, dynamic>? query}) =>
      _guard(() => dio.delete<T>(path, data: data, queryParameters: query));

  Future<Response<T>> _guard<T>(Future<Response<T>> Function() call) async {
    final problem = checkConfig ? apiConfigProblem : null;
    if (problem != null) throw ApiException(ApiErrorKind.notConfigured, problem);
    try {
      return await call();
    } on DioException catch (e) {
      throw ApiException.fromDio(e);
    }
  }
}

/// Adds "Authorization: Bearer `token`" to every request.
class AuthInterceptor extends Interceptor {
  AuthInterceptor({required this.tokenProvider});

  /// TODO(login): the ONE place to swap the dev token for the signed-in user's token once the
  /// backend has a login API (read it from the session, refresh on 401).
  final String Function() tokenProvider;

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    final token = tokenProvider();
    if (token.isNotEmpty) options.headers['Authorization'] = 'Bearer $token';
    handler.next(options);
  }
}

/// Debug builds only: one line per request / response, with the token hidden.
class DebugLogInterceptor extends Interceptor {
  final _started = <RequestOptions, DateTime>{};

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    _started[options] = DateTime.now();
    debugPrint('[API] → ${options.method} ${options.uri}');
    handler.next(options);
  }

  @override
  void onResponse(Response<dynamic> response, ResponseInterceptorHandler handler) {
    debugPrint('[API] ← ${response.statusCode} ${response.requestOptions.uri} ${_ms(response.requestOptions)}');
    handler.next(response);
  }

  @override
  void onError(DioException err, ErrorInterceptorHandler handler) {
    final body = '${err.response?.data ?? ''}';
    debugPrint(
      '[API] ✗ ${err.response?.statusCode ?? err.type.name} ${err.requestOptions.uri} ${_ms(err.requestOptions)} '
      '${body.length > 500 ? '${body.substring(0, 500)}…' : body}',
    );
    handler.next(err);
  }

  String _ms(RequestOptions o) {
    final start = _started.remove(o);
    return start == null ? '' : '(${DateTime.now().difference(start).inMilliseconds} ms)';
  }
}
