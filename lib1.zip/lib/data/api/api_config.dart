/// Backend settings, passed at run time only (never hard-coded):
///
/// ```sh
/// flutter run --dart-define=USE_API=true \
///   --dart-define=API_BASE_URL=http://<backend-ip>:5296 \
///   --dart-define=DEV_TOKEN=<token>
/// ```
///
/// See README → "Connecting to the backend".
library;

/// True: repositories use the backend; false (default): the mock data in lib/data/mock/.
const bool kUseApi = bool.fromEnvironment('USE_API');

/// API Gateway root, e.g. http://192.168.1.20:5296 (no trailing /api).
const String kApiBaseUrl = String.fromEnvironment('API_BASE_URL');

/// Bearer token from the backend developer (there is no login API yet).
const String kDevToken = String.fromEnvironment('DEV_TOKEN');

/// What is missing to call the backend, or null when the base URL and token are both set.
String? get apiConfigProblem => switch (kApiBaseUrl) {
  '' => 'API_BASE_URL is not set. Run with --dart-define=API_BASE_URL=http://<backend-ip>:5296',
  _ when Uri.tryParse(kApiBaseUrl)?.hasScheme != true =>
    'API_BASE_URL "$kApiBaseUrl" must start with http:// or https://',
  _ when kDevToken.isEmpty =>
    'DEV_TOKEN is not set. Run with --dart-define=DEV_TOKEN=<token from the backend developer>',
  _ => null,
};
