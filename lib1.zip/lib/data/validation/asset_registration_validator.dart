import 'package:asset360_mobile/data/models/asset_registration.dart';
import 'package:asset360_mobile/data/models/asset_registration_mapping.dart';

/// Register Asset validation, the same rules as the backend. Errors are keyed by the backend's
/// field path inside the step's request DTO (ASP.NET / FluentValidation style, e.g.
/// "Purchase.PurchaseCost" in AssetPurchaseWarrantyDto), so an API 400 response can later be
/// shown under the same field with no mapping.
///
/// - Next checks the step with [requireMandatory] = true.
/// - Save as Draft checks every step with [requireMandatory] = false: empty fields are fine, but
///   any value entered must be valid.
abstract final class RegistrationValidator {
  /// Steps with fields (0 … 4); step 5 is Review.
  static const formSteps = 5;

  /// Max length of Purchase.Remarks.
  static const remarksMax = 500;

  /// Error for a tag that another asset already has (the backend's own message).
  static String duplicateTag(String tag) => "An asset with tag '$tag' is already registered.";

  /// Field path → message for [step]. [tagOwner] returns the asset ID already using a tag /
  /// barcode / RFID value, or null when it is free.
  static Map<String, String> validateStep(
    AssetRegistration r,
    int step, {
    required bool requireMandatory,
    String? Function(String code)? tagOwner,
  }) {
    final e = <String, String>{};
    void need(String key, String label, Object? value) {
      if (!requireMandatory || e.containsKey(key)) return;
      if (value == null || (value is String && value.trim().isEmpty)) e[key] = '$label is required.';
    }

    switch (step) {
      case 0:
        final b = r.basicInformation;
        need('AssetName', 'Asset Name', b.assetName);
        need('AssetTag', 'Asset Tag', b.assetTag);
        need('Status', 'Status', b.status);
        final tag = AssetTag.normalize(b.assetTag);
        if (tag != null && tagOwner?.call(tag) != null) e['AssetTag'] = duplicateTag(tag);
        // Barcode / RFID are matched by scans too, so the app keeps them unique (the asset's own
        // tag may double as its barcode).
        for (final (key, label, value) in [
          ('Barcode', 'Barcode', b.barcode),
          ('RfidTagId', 'RFID Tag ID', b.rfidTagId),
        ]) {
          final code = AssetTag.normalize(value);
          if (code == null || code == tag) continue;
          final owner = tagOwner?.call(code);
          if (owner != null) e[key] = "$label '$code' is already used by $owner.";
        }
      case 1:
        final c = r.classification;
        need('Category', 'Category', c.category);
        need('SubCategory', 'Sub Category', c.subCategory);
        need('AssetType', 'Asset Type', c.assetType);
        need('Criticality', 'Criticality', c.criticality);
        need('Department', 'Department', c.department);
        need('TaggingMethod', 'Tagging Method', c.taggingMethod);
        need('LifecycleStage', 'Lifecycle Stage', c.lifecycleStage);
      case 2:
        final l = r.locationAssignment.location, a = r.locationAssignment.assignment;
        need('Location.CountryId', 'Country', l.countryId);
        need('Location.SiteId', 'Site', l.siteId);
        need('Location.BuildingId', 'Building', l.buildingId);
        need('Location.FloorId', 'Floor', l.floorId);
        need('Assignment.CustodianDepartment', 'Custodian / Department', a.custodianDepartment);
        if (a.assignmentStartDate != null &&
            a.assignmentEndDate != null &&
            a.assignmentEndDate!.isBefore(a.assignmentStartDate!)) {
          e['Assignment.AssignmentEndDate'] = 'Assignment End Date must be on or after the Assignment Start Date.';
        }
      case 3:
        final p = r.purchaseWarranty.purchase, w = r.purchaseWarranty.warranty;
        need('Purchase.PurchaseOrderNumber', 'Purchase Order Number', p.purchaseOrderNumber);
        need('Purchase.SupplierVendor', 'Supplier / Vendor', p.supplierVendor);
        need('Purchase.Manufacturer', 'Manufacturer', p.manufacturer);
        need('Purchase.PurchaseDate', 'Purchase Date', p.purchaseDate);
        need('Purchase.PurchaseCost', 'Purchase Cost', p.purchaseCost);
        need('Purchase.Quantity', 'Quantity', p.quantity);
        if (p.quantity != null && p.quantity! <= 0) e['Purchase.Quantity'] = 'Quantity must be greater than 0.';
        if (p.purchaseCost != null && p.purchaseCost! < 0) {
          e['Purchase.PurchaseCost'] = 'Purchase Cost must be 0 or more.';
        }
        if (p.taxPercent != null && (p.taxPercent! < 0 || p.taxPercent! > 100)) {
          e['Purchase.TaxPercent'] = 'Tax % must be between 0 and 100.';
        }
        if (p.purchaseDate != null && p.deliveryDate != null && p.deliveryDate!.isBefore(p.purchaseDate!)) {
          e['Purchase.DeliveryDate'] = 'Delivery Date must be on or after the Purchase Date.';
        }
        if ((p.remarks ?? '').length > remarksMax) {
          e['Purchase.Remarks'] = 'Remarks must be $remarksMax characters or fewer.';
        }
        if (w.warrantyPeriod != null) {
          if (w.warrantyPeriod! <= 0) e['Warranty.WarrantyPeriod'] = 'Warranty Period must be greater than 0.';
          if ((w.warrantyPeriodUnit ?? '').trim().isEmpty) {
            e['Warranty.WarrantyPeriodUnit'] = 'Warranty Period Unit is required when a period is given.';
          }
        }
      default:
        break; // Step 5 (Additional Information) has no backend rules.
    }
    return e;
  }

  /// First step (0 … 4) with an error and its errors, or null when the registration is valid.
  static ({int step, Map<String, String> errors})? firstInvalid(
    AssetRegistration r, {
    required bool requireMandatory,
    String? Function(String code)? tagOwner,
  }) {
    for (var s = 0; s < formSteps; s++) {
      final errors = validateStep(r, s, requireMandatory: requireMandatory, tagOwner: tagOwner);
      if (errors.isNotEmpty) return (step: s, errors: errors);
    }
    return null;
  }
}
