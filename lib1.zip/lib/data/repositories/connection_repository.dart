import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:asset360_mobile/data/api/api_client.dart';
import 'package:asset360_mobile/data/api/api_exception.dart';

/// Result of Administration → Backend API → Test connection.
class ConnectionResult {
  const ConnectionResult({required this.path, required this.statusCode, required this.elapsed, this.itemCount});

  final String path;
  final int statusCode;
  final Duration elapsed;

  /// Records in the reply when it is a list (or has an `items` list); null otherwise.
  final int? itemCount;
}

/// Test connection: one simple authenticated GET through the API Gateway.
/// State: null = not tested yet; loading while the call runs; error = an [ApiException].
class ConnectionTestNotifier extends AsyncNotifier<ConnectionResult?> {
  /// GET /api/asset-categories (A360.Asset.Api in docs/api_samples/swagger.json): read-only and needs
  /// the Bearer token, so a success proves the URL, the gateway route and the token.
  static const testPath = '/api/asset-categories';

  @override
  ConnectionResult? build() => null;

  Future<void> run() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() async {
      final watch = Stopwatch()..start();
      try {
        final res = await ref.read(apiClientProvider).get<Object?>(testPath);
        final data = res.data;
        final items = data is List ? data : (data is Map && data['items'] is List ? data['items'] as List : null);
        return ConnectionResult(
          path: testPath,
          statusCode: res.statusCode ?? 200,
          elapsed: watch.elapsed,
          itemCount: items?.length,
        );
      } catch (e) {
        throw ApiException.from(e);
      }
    });
  }
}

final connectionTestProvider = AsyncNotifierProvider<ConnectionTestNotifier, ConnectionResult?>(
  ConnectionTestNotifier.new,
);
