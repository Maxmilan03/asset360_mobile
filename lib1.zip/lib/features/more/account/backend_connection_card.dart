import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:asset360_mobile/app/theme/app_colors.dart';
import 'package:asset360_mobile/app/theme/app_text.dart';
import 'package:asset360_mobile/core/widgets/widgets.dart';
import 'package:asset360_mobile/data/api/api_config.dart';
import 'package:asset360_mobile/data/api/api_exception.dart';
import 'package:asset360_mobile/data/repositories/connection_repository.dart';

/// Administration → Backend API: the run-time settings (USE_API, API_BASE_URL, DEV_TOKEN) and a
/// Test connection button (one authenticated GET through the API Gateway).
class BackendConnectionCard extends ConsumerWidget {
  const BackendConnectionCard({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final test = ref.watch(connectionTestProvider);
    final token = kDevToken.isEmpty
        ? 'Not set'
        : 'Set (…${kDevToken.length > 4 ? kDevToken.substring(kDevToken.length - 4) : ''})';
    return SectionCard(
      title: 'Backend API',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const InfoRow(
            label: 'Data source',
            value: kUseApi ? 'Backend (USE_API=true)' : 'Demo mock data (USE_API off)',
            labelWidth: 96,
          ),
          InfoRow(label: 'Base URL', value: kApiBaseUrl.isEmpty ? 'Not set' : kApiBaseUrl, labelWidth: 96),
          InfoRow(label: 'Dev token', value: token, labelWidth: 96),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: test.isLoading ? null : () => ref.read(connectionTestProvider.notifier).run(),
            icon: test.isLoading
                ? const SizedBox.square(
                    dimension: 18,
                    child: CircularProgressIndicator(strokeWidth: 2.2, color: Colors.white),
                  )
                : const Icon(Icons.wifi_tethering_rounded, size: 20),
            label: Text(test.isLoading ? 'Testing…' : 'Test connection'),
          ),
          const SizedBox(height: 10),
          switch (test) {
            AsyncData(value: final r?) => _Result(
              ok: true,
              title: 'Connected',
              message:
                  'GET ${r.path} → ${r.statusCode} in ${r.elapsed.inMilliseconds} ms'
                  '${r.itemCount == null ? '' : ' · ${r.itemCount} records'}',
            ),
            AsyncError(:final error) => _Result(
              ok: false,
              title: 'Connection failed',
              message: ApiException.from(error).message,
            ),
            AsyncLoading() => Text('Calling ${ConnectionTestNotifier.testPath} …', style: AppText.caption),
            _ => Text('Calls GET ${ConnectionTestNotifier.testPath} with the dev token.', style: AppText.caption),
          },
        ],
      ),
    );
  }
}

class _Result extends StatelessWidget {
  const _Result({required this.ok, required this.title, required this.message});

  final bool ok;
  final String title;
  final String message;

  @override
  Widget build(BuildContext context) {
    final color = ok ? AppColors.green : AppColors.red;
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: ok ? AppColors.greenBg : AppColors.redBg,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(ok ? Icons.check_circle_rounded : Icons.error_outline_rounded, color: color, size: 20),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: AppText.bodyStrong.copyWith(color: color)),
                const SizedBox(height: 2),
                Text(message, style: AppText.caption),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
